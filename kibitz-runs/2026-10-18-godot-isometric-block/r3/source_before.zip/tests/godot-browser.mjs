import { mkdir, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE ? pathToFileURL(process.env.PLAYWRIGHT_MODULE).href : 'playwright');
await mkdir('artifacts', { recursive: true });
const browser = await chromium.launch({ channel: 'chrome', headless: true });
const errors = [], external = [], runs = [];
try {
  for (const size of [{ width: 1100, height: 760 }, { width: 390, height: 667 }]) {
    const page = await browser.newPage({ viewport: size });
    page.on('pageerror', e => errors.push(e.message));
    page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('request', r => { if (!r.url().startsWith('http://127.0.0.1:4174/') && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) external.push(r.url()); });
    await page.goto('http://127.0.0.1:4174/');
    await page.locator('#status').waitFor({ state: 'hidden', timeout: 60000 });
    await page.waitForTimeout(1200);
    const before = await page.screenshot({ path: `artifacts/godot-${size.width}-overview.png` });
    // Native Godot Control buttons are canvas pixels, not DOM accessibility nodes.
    // Click Next at the bottom-right top row; verify an actual rendered change.
    await page.mouse.click(size.width * (size.width < 600 ? .25 : .83), size.height - 98);
    await page.waitForTimeout(300);
    const after = await page.screenshot({ path: `artifacts/godot-${size.width}-selected.png` });
    assert.notDeepEqual(before, after, `Next building must change view at ${size.width}`);
    await page.keyboard.press('Tab');
    await page.keyboard.press('Enter');
    await page.waitForTimeout(150);
    runs.push({ viewport: size, overviewBytes: before.length, selectedBytes: after.length, keyboardAttempted: true });
    await page.close();
  }
  assert.deepEqual(external, []);
  assert.deepEqual(errors, []);
  await writeFile('artifacts/godot-browser.json', JSON.stringify({ runs, errors, external, limit: 'Pixel-change and driver-inspected screenshots, not DOM/screen-reader or physical-phone acceptance.' }, null, 2));
  console.log(JSON.stringify({ runs, errors, external }));
} finally { await browser.close(); }
