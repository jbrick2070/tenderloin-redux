# Godot approach — creator decision, 2026-10-18

Build a stylized isometric/2.5D Godot version, beginning with a separately runnable block before wider migration. Preserve browser 0.12.0 and its saves while testing the new engine. Neither track is a finished release.

`godot/` is a Godot 4.7.2 standard/GDScript Compatibility project. It now combines the **58-building measured geography study** around Turk/Taylor/Mason with **actual-scale walking, building collision, camera sightline cutaway, and bounded keyboard/touch neighbor navigation**:
- **Measured geometry**: 58 city building records (`DataSF ynuv-fyni`, PDDL 1.0) at 1:1 metre scale with exact rings, parts, courtyards, and median above-ground height (`hgt_mediancm / 100`), plus derived OpenStreetMap (`ODbL 1.0`) street centerlines, schematic sidewalk bands, roadway, and dashed centerlines.
- **Actual-scale walking & collision**: `CharacterBody3D` player (`1.72 m` height, `0.45 m` radius, `4.8 m/s` speed) with `StaticBody3D` + `ConcavePolygonShape3D` on all 58 buildings and exact 2D polygon/courtyard-hole sub-stepped collision and angled-wall sliding.
- **Neighbor navigation & camera cutaway**: 5 neighbors (`Bea`, `Celeste`, `Rook`, `Dez`, `Thanh`) on verified sidewalks (`>= 2.39 m` wall clearance), sidewalk pathfinding with 3D route ribbon, `"Walk to neighbor"` button (`>= 44 px` at `1100x760`, `390x667`, `320x667`), keyboard shortcuts (`WASD`/Arrows, `1`–`5`, `N`/`B`, `F`, `Esc`), 3D scene tap/drag, and automatic translucent camera occlusion cutaway when tall buildings cross the sightline to the player or active neighbor without moving or altering building geometry.

[San Francisco Building Footprints](https://data.sf.gov/Geographic-Locations-and-Boundaries/Building-Footprints/ynuv-fyni) provides full footprint rings and LiDAR height statistics under PDDL. City method identifies Pictometry **2010** data and a method prepared 2017-05-01. Portal refresh times do not establish current buildings. Keep actual rings, parts and courtyards; use above-ground `hgt_mediancm / 100`, never absolute NAVD88 roof elevation as height. Median-height LoD1 extrusion is not an exact roofline or floor count. Flat presentation ground does not reproduce terrain; street widths are schematic. Current façades, entrances, crossings and decorations remain separate verification work. [Provenance](../godot/data/SOURCES.md).

Google Open Buildings V3's [published coverage](https://sites.research.google/gr/open-buildings/) does not include North America or San Francisco, and Google Maps Platform 3D Tiles / Street View require a live billed Google Cloud API key and prohibit scraping, pre-fetching, caching, or redistributing derived meshes/imagery in an offline MIT repository under Google Maps Platform Terms of Service (Section 3.2.3) even for non-commercial projects. City PDDL footprints + OpenStreetMap ODbL streets remain the verified open-data foundation here. No Google imagery/mesh/texture imported.

## Next implementation rounds

1. The geography foundation (Round 1) and actual-scale walking, building collision, camera sightline cutaway, and keyboard/touch neighbor navigation (Round 2) are checked and reviewed; see BUILD_STATUS for receipts. Do not pay to re-review unchanged source.
2. Add one fictional neighbor interaction and original portable mural at an authored access-aware game location. Prove talking, painting, visible consequence, reload and keyboard/touch play; do not claim permission to paint a real façade.
3. Add original music and progress cues with explicit playback; preserve the creator's local Suno import option/provenance brief. No Suno audio bundled yet. Listen before claiming musical quality.
4. Validate the block before wider migration. Browser-save compatibility requires an explicit adapter; this study does not read or write those saves. Test mobile controls/accessibility before replacing the DOM-based browser experience.
5. Expand M2/Godot geography across the **whole Tenderloin neighborhood** (not just the Transgender Cultural District or the opening Turk/Taylor/Mason block) using dated DataSF `ynuv-fyni` PDDL footprints and OpenStreetMap ODbL streets while keeping the Transgender Cultural District boundary as a verified cultural/historical layer within the wider Tenderloin.
6. Carry forward the entire M0–M6 roadmap: resident-led projects and later gatherings, accurate wider district/history/culture/nonprofits/festivals, civic events/filming and default-off Neighborhood Voices. Existing human/current-location/release acceptance remains open.

## Local run

Open `godot/project.godot` in Godot 4.7.2 standard. The official portable engine and matching templates are verified in the user cache, outside Git. No .NET or global installation needed. With Godot on PATH:

```powershell
node scripts/build-godot-data.mjs
godot --headless --path godot --editor --import --quit
godot --path godot
```

For a browser preview, install official matching Web templates, create `artifacts/godot-web/`, then:

```powershell
godot --headless --path godot --export-release Web
node scripts/serve-godot.mjs
```

Study: http://127.0.0.1:4174/ . Existing game: http://127.0.0.1:4173/ . Generated exports/cache are ignored. Data regeneration is offline/deterministic; source refresh must be deliberate, dated and reverified. `npm test` includes geometry checks. `node tests/godot-browser.mjs` uses existing Playwright setup; canvas pixel changes/screenshots do not establish screen-reader speech or physical-phone feel.

## Scheduler and remote checkpoints

The creator requested a handoff to AGY 4 and stopped the Codex hourly work at this checkpoint. Existing `build-tenderloin-redux` heartbeat is **PAUSED**, verified through app tool/configuration; keep it paused. Creator subsequently authorized **AGY's own hourly scheduler** after sole-writer takeover. Use Gemini 4 Argon High as builder. Each implementation turn should get other-model CLI QA when possible: native Claude Opus5.5/High first, independent Codex SolHigh if unavailable. Exclude the AGY driver from independent-family review. If neither is available, creator explicitly allows a Gemini Flash3.8 QA subagent when that exact model is available; label it a same-family fallback, never fabricate independence/model identity. If no reviewer runs, retain an explicitly unreviewed checkpoint and report the gap. Carry this policy into AGY's scheduler; avoid overlapping writers, large panels, paid retries or unchanged-code re-reviews. Detailed runner policy in session_handoff.md. Regular tested, honestly reviewed commits/pushes authorized. Exclude secrets/binaries/caches/generated bulk; preserve user work/reports, no force push. Retain local work/report auth/conflict/rejection blockers. Notify meaningful changes; stop AGY scheduling when full-game acceptance is met.

The npm launchers use GODOT_BIN if set, otherwise the verified Windows user cache or `godot` on PATH. Run in order: `npm run godot:data`, `npm run godot:import`, `npm run godot:test`, `npm run godot:export`. Start `npm run godot:serve` in another terminal **before** `npm run godot:browser` (requires Playwright). `npm run check` includes the Godot JS syntax checks. Use GODOT_PORT for a different preview port in both server and browser tests. Native rule/UI checks can run separately with `godot --headless --path godot --script res://tests/study_test.gd`.
